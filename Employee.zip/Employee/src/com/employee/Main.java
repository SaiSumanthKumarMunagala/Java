package com.employee;

public class Main {

    public static void main(String[] args) {


        Employee e =new Employee();
        e.action();




    }
}
