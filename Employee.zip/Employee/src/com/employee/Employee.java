package com.employee;

public class Employee{
    int age;
    String name="sumanth kumar";
    String city="hyderabad";
    String name1="vinay";
    String city1="hyderabad";


    public void action(){
        System.out.printf("The name is %s%n", name);
        System.out.printf("The city is %s%n", city);
        Employee e1 = new Employee();
        e1.age= 21;
        System.out.printf("The age is %s%n", e1.age);
        System.out.printf("The name is %s%n",name1);
        System.out.printf("The city is %s%n", city1);
        Employee e2 = new Employee();
        e2.age= 17;
        System.out.printf("The age is %s%n", e2.age);


    }
}

